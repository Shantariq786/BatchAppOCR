//
//  ExtractingTextViewController.swift
//  BatchAppOCR
//
//  Created by Hexacrew on 21/01/2022.
//

import UIKit
import Firebase

class ExtractingTextViewController: UIViewController {
    
    @IBOutlet weak var topTextView: UITextView!
    @IBOutlet weak var bottomTextView: UITextView!
    @IBOutlet weak var imagesCollectionView: UICollectionView!
    lazy var vision = Vision.vision()
    var textDetector: VisionTextDetector?
    
    var selectedImages = [UIImage]()
    var textArray = [String]()
    var totalImageConvertedCount = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()

        imagesCollectionView.delegate = self
        imagesCollectionView.dataSource = self
        self.imagesCollectionView.register(UINib(nibName: "ExtractingTextColelctionViewCell", bundle: nil), forCellWithReuseIdentifier: "ExtractingTextColelctionViewCell")
        
        bottomTextView.delegate = self
        bottomTextView.text = "Placeholder"
        bottomTextView.textColor = UIColor.lightGray
        
        textArray = Array(repeating: "", count: selectedImages.count)
        extractTextFromImagesArray()
       
    }
    
    func extractTextFromImagesArray(){
        for i in 0..<selectedImages.count{
            detectText(image: selectedImages[i]) {[self] imageText in
                textArray[i] = imageText
                
                totalImageConvertedCount = totalImageConvertedCount+1
                
                // print when everything will be done
                if totalImageConvertedCount == selectedImages.count{
                    topTextView.text = textArray.joined(separator: "\n\n")
                }
            }
        }
    }
    
    
    @IBAction func pasteHereBtnTapped(_ sender: Any) {
    }
    
    @IBAction func topPDFBtnTapped(_ sender: Any) {
    }
    
    @IBAction func topDocxBtnTapped(_ sender: Any) {
    }
    
    @IBAction func toTextBtnTapped(_ sender: Any) {
    }
    
    // bottom button
    @IBAction func bottomPDFBtnTapped(_ sender: Any) {
    }
    
    @IBAction func bottomDocxBtnTapped(_ sender: Any) {
    }
    
    @IBAction func bottomTextBtnTapped(_ sender: Any) {
    }
    
}

//MARK: -                       COLLECTIOVIEW PROTOCOLS
extension ExtractingTextViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ExtractingTextColelctionViewCell", for: indexPath) as! ExtractingTextColelctionViewCell
        cell.imageview.image = selectedImages[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 90, height: 90)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("tapped at \(indexPath)")
        topTextView.text = textArray[indexPath.row]
    }
    
    
    
}


//MARK: -                           TEXTVIEW DELEGETES
extension ExtractingTextViewController:UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if bottomTextView.textColor == UIColor.lightGray {
            bottomTextView.text = nil
            bottomTextView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if bottomTextView.text.isEmpty {
            bottomTextView.text = "Placeholder"
            bottomTextView.textColor = UIColor.lightGray
        }
    }
}


// MARK: -                          DETEXT TEXT

extension ExtractingTextViewController{
    func detectText (image: UIImage, completion:@escaping (String)->Void){
        
        textDetector = vision.textDetector()
        
        let visionImage = VisionImage(image: image)
        
        textDetector?.detect(in: visionImage) { (features, error) in
            guard error == nil, let features = features, !features.isEmpty else {
                return
            }
            
            debugPrint("Feature blocks in th image: \(features.count)")
            
            var detectedText = [String]()
            for feature in features {
                let value = feature.text
                detectedText.append("\(value) ")
            }
            
            print("detectedText \(detectedText)")
            completion(detectedText.joined(separator: "\n"))
            
        }
    }
}
